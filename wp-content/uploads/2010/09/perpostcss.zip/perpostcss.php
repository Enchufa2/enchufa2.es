<?php

/*
Plugin Name: Per-Post CSS
Version: 1.1
Plugin URI: http://trevorcreech.com/geekery/wordpress/per-post-css/
Description: This plugin allows you to specify a chunk of CSS, which will be included in the header only when viewing that post, or a page where that post appears.  Put the custom CSS in a Custom Field called "Per-Post CSS".  The Custom Fields interface can be found directly below the file upload interface when you are creating or editing a post.
Author: Trevor Creech
Author URI: http://trevorcreech.com
*/

function ppc_header()
{
	global $posts;
	for($i=0;$i<count($posts);$i++)
	{
		$ppc_embed = get_post_meta($posts[$i]->ID, 'Per-Post CSS', false);
		$ppc_ext = get_post_meta($posts[$i]->ID, 'Per-Post CSS File', false);
		for($j=0;$j<count($ppc_embed);$j++)
		{
			$ppc_output .=  '/* Embedded CSS for "' . $posts[$i]->post_title . "\" */\n"; 
			$ppc_output .= $ppc_embed[$j] . "\n";
		}
		for($j=0;$j<count($ppc_ext);$j++)
		{
			$ppc_output .=  '/* Externel CSS for "' . $posts[$i]->post_title . "\" */\n"; 
			$ppc_output .= "@import url(\"$ppc_ext[$j]\")" . "\n";
		}
	}
	if($ppc_output)
	{
		echo "<style type=\"text/css\">\n/* Per-Post CSS */\n";
		echo $ppc_output;
		echo "</style>\n";
	}
}

add_action('wp_head', 'ppc_header');
?>
