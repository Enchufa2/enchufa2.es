#!/bin/bash

# how long to sleep between drawings
sleep=2m

# screen size
geometry=1600x900

# logfile
logFile=${HOME}/.xplanet/xplanet.log

# Download a new cloud file
download_clouds.py ${HOME}/.xplanet/images/clouds_2048.jpg

# The xplanet command
xplanet -num_times 1 -geometry $geometry -radius 40  \
        -body earth -random -range 20 -label -labelpos +10+10  \
        -config ${HOME}/.xplanet/xplanet.conf  \
	-output ${HOME}/xplanet-img/pic.jpg >> $logFile

mv ${HOME}/xplanet-img/pic.jpg ${HOME}/xplanet-img/xplanet.jpg

sleep ${sleep}

# Run this script again
exec $0
